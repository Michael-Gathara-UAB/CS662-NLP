GeneRIF text for pretraining
